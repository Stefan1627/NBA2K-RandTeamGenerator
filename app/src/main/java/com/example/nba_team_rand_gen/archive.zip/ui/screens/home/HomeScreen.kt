package com.example.nba_team_rand_gen.ui.screens.home

import android.net.Uri
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun HomeScreen(
    vm: HomeViewModel = viewModel(),
    onNavigateShow: (String) -> Unit
) {
    val s by vm.state.collectAsStateWithLifecycle()

    // dropdown-uri simple
    Dropdown(
        label = "Type", options = listOf("All","Current","Classic","All-time"),
        selected = s.type, onSelect = { vm.onEvent(HomeEvent.OnType(it)) }
    )
    Dropdown(
        label = "Game", options = listOf("1vs1","2vs2","3vs3","4vs4","5vs5"),
        selected = s.game, onSelect = { vm.onEvent(HomeEvent.OnGame(it)) }
    )
    Button(onClick = { vm.onEvent(HomeEvent.Randomize) }) { Text("Random") }

    s.navigateToShow?.let {
        onNavigateShow(Uri.encode(it))
        vm.onEvent(HomeEvent.NavConsumed)
    }
}

@Composable
fun Dropdown(label: String, options: List<String>, selected: String, onSelect: () -> Unit) {
    TODO("Not yet implemented")
}
