package com.example.nba_team_rand_gen.domain.usecase

import com.example.nba_team_rand_gen.RandomizeGame
import com.example.nba_team_rand_gen.data.model.PlayerWithTeam

class RandomizeTeamsUseCase {
    operator fun invoke(type: String, game: String): List<PlayerWithTeam> {
        return RandomizeGame(root.context).randomize(type, game)
    }
}