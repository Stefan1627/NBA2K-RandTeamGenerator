package com.example.nba_team_rand_gen.data.repo

import android.widget.Toast
import com.example.nba_team_rand_gen.data.model.PlayerWithTeam
import com.example.nba_team_rand_gen.domain.repo.MatchesRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class MatchesRepositoryImpl(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth
) : MatchesRepository {

    private fun userDoc() = db.collection("users").document(auth.currentUser!!.uid)

    override suspend fun saveMatch(name: String, teams: List<PlayerWithTeam>) {
        withContext(Dispatchers.IO) {
            val entry = mapOf("name" to name, "data" to Json.encodeToString(teams))
            userDoc().update("matchesList", FieldValue.arrayUnion(entry)).await()
        }
    }

    override fun favorites(): Flow<List<Match>> = callbackFlow {
        val reg = userDoc().addSnapshotListener { snap, err ->
            if (err != null) { close(err); return@addSnapshotListener }
            val list = (snap?.get("favoritesList") as? List<Map<String, Any?>>)
                .orEmpty()
                .map { Match.fromMap(it) }
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    override fun history(): Flow<List<Match>> = callbackFlow {
        val reg = userDoc().addSnapshotListener { snap, err ->
            if (err != null) { close(err); return@addSnapshotListener }
            val list = (snap?.get("matchesList") as? List<Map<String, Any?>>)
                .orEmpty()
                .map { Match.fromMap(it) }
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    override suspend fun toggleFavorite(matchId: String) {
        Toast.makeText(it, "Coming soon...", Toast.LENGTH_SHORT).show()
    }
    override suspend fun deleteMatch(matchId: String) {
        Toast.makeText(it, "Coming soon...", Toast.LENGTH_SHORT).show()
    }
}