package com.example.nba_team_rand_gen.data.model

import com.example.nba_team_rand_gen.Player
import kotlinx.serialization.Serializable

@Serializable
data class PlayerWithTeam(
    val player: Player,
    val teamName: String
)
